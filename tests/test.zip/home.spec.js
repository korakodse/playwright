import { test, expect } from '@playwright/test';
test('Teacher Home@api', async ({ request }) => {

  const response = await request.get('http://52.63.155.211/api/teacher/home', {
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer 57a4fcb30e016e93efe9649fbd381954c228f6bce15c96d5b91855d15b7e8297",
    },
  });

    expect(response.status()).toBeGreaterThanOrEqual(100);
    expect(response.status()).toBeLessThan(600);

    const res = await response.json();
    console.log('📩 Response Data:', res);

});