import { test, expect } from '@playwright/test';
import fs from 'fs';

test('reportatten@api', async ({ request }) => {
  const response = await request.get('http://52.63.155.211/classrooms/7/attendance-pdf/2376fbf2b93f8d77083f77a9a55097a4694dc184686dbfb5cc1f68702a916bb5', {
    headers: {
      "Content-Type": "application/json",
    },
  });

  expect(response.status()).toBe(200);

  // ตรวจสอบ content-type
  expect(response.headers()['content-type']).toContain('application/pdf');

  // ดาวน์โหลด PDF ไปยังไฟล์เพื่อเช็กขนาด/เปิดดู
  const buffer = await response.body();
  expect(buffer.byteLength).toBeGreaterThan(0);

  fs.writeFileSync('at-risk_report_test.pdf', buffer);
  console.log('✅ PDF saved as at-risk_report_test.pdf, size:', buffer.byteLength);

});

test('homedownload@api', async ({ request }) => {
  const response = await request.get('http://52.63.155.211/student/home-attendance-pdf/6b6be87bdfae37e9d92e5bdadb1a6ca10a1473b11757a3c75f5cff0479c32f7c', {
    headers: {
      "Content-Type": "application/json",
    },
  });

    expect(response.status()).toBe(200);

  // ตรวจสอบ content-type
  expect(response.headers()['content-type']).toContain('application/pdf');

  // ดาวน์โหลด PDF ไปยังไฟล์เพื่อเช็กขนาด/เปิดดู
  const buffer = await response.body();
  expect(buffer.byteLength).toBeGreaterThan(0);

  fs.writeFileSync('homeStudent.pdf', buffer);
  console.log('✅ PDF saved as homeStudent.pdf, size:', buffer.byteLength);

});