import { test, expect } from '@playwright/test';

test('logout@api', async ({ request }) => {
  const response = await request.post('http://52.63.155.211/api/logout', {
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer 083e245bd5a6c8e8b0abe97b250228741fedb6449d4c3a18f1f17da6429c75d7",
    },
  });

  expect(response.status()).toBeGreaterThanOrEqual(100);
  expect(response.status()).toBeLessThan(600);

  const res = await response.json();
  console.log('📩 Response Data:', res);
});
